
# Calendar App for ENTNT
A React-based Calendar Application for communication tracking, created by Shaguftha.

## Features
1. Admin Module for managing companies and communication settings.
2. User Module for managing and viewing tasks.
3. Dashboard with color-coded highlights for communication tracking.
4. Reporting and Analytics Module (optional).
5. Notifications for overdue and upcoming communications.
