
import React from 'react';

const User = () => {
    return (
        <div>
            <h2>User Module</h2>
            <p>Manage tasks and view notifications here.</p>
        </div>
    );
};

export default User;
