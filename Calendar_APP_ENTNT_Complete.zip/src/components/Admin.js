
import React from 'react';

const Admin = () => {
    return (
        <div>
            <h2>Admin Module</h2>
            <p>Manage companies and communication settings here.</p>
        </div>
    );
};

export default Admin;
